from django.shortcuts import render, redirect
from .models import Edital  

def editais_view(request):
    editais = Edital.objects.all()  # Pega todos os editais
    return render(request, 'editais.html', {'editais': editais})

def add_edital_view(request):
    return render(request, 'add_edital.html')

def save_edital(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        data = request.POST.get('data')
        # Salvar o edital no banco de dados
        edital = Edital(nome=nome, data=data)
        edital.save()
        return redirect('editais')  # Redireciona para a página de editais

def edit_edital_view(request, id):
    edital = Edital.objects.get(id=id)
    if request.method == 'POST':
        edital.nome = request.POST.get('nome')
        edital.data = request.POST.get('data')
        edital.save()
        return redirect('editais')
    return render(request, 'edit_edital.html', {'edital': edital})

def delete_edital(request, id):
    edital = Edital.objects.get(id=id)
    edital.delete()
    return redirect('editais')