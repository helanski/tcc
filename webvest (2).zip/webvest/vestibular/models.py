from datetime import date
from django.db import models

class Usuario(models.Model):
    nomeUsuario = models.CharField(max_length=100, null=False)
    email = models.EmailField(max_length=50, null=False)
    senha = models.IntegerField(null=False)  
    
class Edital(models.Model):
    edital = models.CharField(max_length=100)
    data = models.DateField()
    Usuario = models.ForeignKey(Usuario, null=False)
    
class Disciplina(models.Model):
    nomeDisciplina = models.CharField(max_length=100, null=False)
    ProvaVestibular = models.ForeignKey(Edital, null=False)

class Conteudo(models.Model):
    nomeConteudo = models.CharField(max_length=100, null=False)
    Disciplina = models.ForeignKey(Disciplina, null=False)
    
class desempenhoConteudo(models.Model):
    numQuestoes = models.IntegerField(max_length=3, default=0)
    acertos = models.IntegerField(max_length=3, default=0)
    erros = models.IntegerField(max_length=3, default=0)
    periodo = models.DateField()
    Conteudo = models.ForeignKey(Conteudo, null = False)
    
