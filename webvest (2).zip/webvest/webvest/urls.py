from django.contrib import admin
from django.urls import include, path
from . import views


urlpatterns = [
    path('editais/', views.editais_view, name='editais'),
    path('add-edital/', views.add_edital_view, name='add_edital'),
    path('save-edital/', views.save_edital, name='save_edital'),
    path('edit-edital/<int:id>/', views.edit_edital_view, name='edit_edital'),
    path('delete-edital/<int:id>/', views.delete_edital, name='delete_edital'),
     path('admin/', admin.site.urls),
    path('', include('webvest.urls')),
]
