from django.urls import path
from . import views

urlpatterns = [
    # Rota para a página inicial (Home)
    path('', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),  # URL para a tela de login
    path('editais/', views.editais_view, name='editais'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('signup/', views.signup_view, name='signup'),
]
