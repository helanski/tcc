from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from .models import Edital
from django.contrib.auth.views import LoginView

def home_view(request):
    return render(request, 'preparacaoVest/home.html')


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')  # Redireciona para o dashboard após login
    else:
        form = AuthenticationForm()
    return render(request, 'preparacaoVest/login.html', {'form': form})


def editais_view(request):
    editais = Edital.objects.all()  # Recupera todos os editais
    return render(request, 'editais.html', {'editais': editais})


class CustomLoginView(LoginView):
    template_name = 'login.html'

    def form_valid(self, form):
        # Aqui você pode personalizar a lógica de sucesso no login, se necessário.
        return super().form_valid(form)
    
    from django.contrib.auth.forms import UserCreationForm

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('preparacaoVest/login')  # Redireciona para a página de login após o sucesso
    else:
        form = UserCreationForm()

    return render(request, 'preparacaoVest/signup.html', {'form': form})