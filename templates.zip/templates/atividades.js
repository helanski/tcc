  // Função para mostrar o status das atividades
  function toggleStatus(checkboxId, statusId) {
    const checkbox = document.getElementById(checkboxId);
    const status = document.getElementById(statusId);
    if (checkbox.checked) {
      status.style.display = 'block';
    } else {
      status.style.display = 'none';
    }
  }

  // Adicionar eventos de mudança para mostrar o status
  document.getElementById('teoriaCheck').addEventListener('change', function() {
    toggleStatus('teoriaCheck', 'teoriaStatus');
  });
  document.getElementById('videoaulaCheck').addEventListener('change', function() {
    toggleStatus('videoaulaCheck', 'videoaulaStatus');
  });
  document.getElementById('resumoCheck').addEventListener('change', function() {
    toggleStatus('resumoCheck', 'resumoStatus');
  });
  document.getElementById('questoesCheck').addEventListener('change', function() {
    toggleStatus('questoesCheck', 'questoesStatus');
  });
